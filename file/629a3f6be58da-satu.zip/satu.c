#include<stdio.h>
#include<string.h>
int n;
void insert(char nama[n][50]){
    for(int i=1; i<n;i++){
        char key[50];
        strcpy(key, nama[i]);
        int j=i-1;
        while(j>=0&&strcmp(key,nama[j])<0){
            strcpy(nama[j+1],nama[j]);
            j--;
        }
        strcpy(nama[j+1],key);
    }
}
void selek(char nama[n][50]){
    for(int i=0;i<n;i++){
        int minindex=i;
        for(int j=i+1;j<n;j++){
            if(strcmp(nama[minindex],nama[j])<0){
                minindex=j;
            }
        }
        char temp[50];
        strcpy(temp, nama[i]);
        strcpy(nama[i], nama[minindex]);
        strcpy(nama[minindex],temp);
    }
}
int main(){
    int k;
    scanf("%d", &n);
    char nama[n][50];
    for(k=0;k<n;k++){
        scanf("%s", &nama[k]);
    }
    char metode[50];
    scanf("%s", &metode);
    if(strcmp(metode, "insertion")==0){
        insert(nama);
    }else if(strcmp(metode, "selection")==0){
        selek(nama);
    }
    printf("Hasil Sorting:\n");
    for(k=0;k<n;k++){
        printf("%s\n", nama[k]);
    }

    return 0;
}