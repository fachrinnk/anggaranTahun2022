#include<stdio.h>
#include<string.h>
int mencari(char str[], char cari[]){
    int hitung=0;
    int i=0,j=0;
    while(i<strlen(str)&&hitung!=strlen(cari)){
        if(str[i]==cari[j]){
            hitung++;
        }else{
            hitung=0;
            j=-1;
        }
        i++;
        j++;
    }
    if(hitung==strlen(cari)){
        return 1;
    }
    return 0;
}

int main(){
    // +32
    char str[100][100];
    int n=0;
    scanf("%s",&str[0]);
    while(strcmp(str[n], ";")!=0){
        for(int i=0; i<strlen(str[n]);i++){
            if(str[n][i]>'A'&&str[n][i]<'Z'){
                str[n][i]+=32;
            }
        }
        n++;
        scanf("%s",&str[n]);
    }
    char cari[100];
    scanf("%s",&cari);
    for(int i=0; i<strlen(cari);i++){
        if(cari[i]>'A'&&cari[i]<'Z'){
            cari[i]+=32;
        }
    }
    int hitung=0;
    for(int i=0;i<n;i++){
        if(mencari(str[i], cari)){
            hitung++;
        }
    }
    // printf("\n%s\n", cari);
    printf("%d\n", hitung);

    return 0;
}