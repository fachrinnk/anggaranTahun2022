#include<stdio.h>

// void sequensearch(int arr[], int n, int search){
//     int i=0, found=0;
//     while(i<n&&found==0){
//         if(arr[i]==search){
//             found=1;
//         }
//         else{
//             i++;
//         }
//     }
//     return found;
// }

int main(){
    int n;
    scanf("%d", &n);
    int arr[n];
    for(int i=0;i<n;i++){
        scanf("%d", &arr[i]);
    }
    int angka;
    scanf("%d", &angka);
    int i=0;
    int paling=-999;
    for(int i=0;i<n;i++){
        if(arr[i]<angka&&arr[i]>paling){
            paling=arr[i];
        }
    }
    printf("%d\n", paling);


    return 0;
}